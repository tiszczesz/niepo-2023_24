package pl.revolshen.fiszki.data.repositories

import android.content.Context
import pl.revolshen.fiszki.data.local.CardsLoader
import pl.revolshen.fiszki.data.model.Card

class CardRepository(context: Context) {
    private val cardsLoader = CardsLoader(context)

    fun loadCards(): Boolean {
        return cardsLoader.load()
    }

    fun getCards(): List<Card> {
        return cardsLoader.get()
    }
}