package pl.revolshen.fiszki.data.model.domain

sealed class MenuEvent {
    data object NewGame : MenuEvent()
    data object History : MenuEvent() // Dorobić logikę z Historią
}
