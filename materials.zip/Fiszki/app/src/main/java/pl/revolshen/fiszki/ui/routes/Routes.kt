package pl.revolshen.fiszki.ui.routes

object Routes {
    const val startScreen = "startScreen"
    const val gameScreen = "gameScreen"
    const val historyScreen = "historyScreen"
}