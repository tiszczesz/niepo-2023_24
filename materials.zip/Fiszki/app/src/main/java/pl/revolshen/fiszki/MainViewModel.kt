package pl.revolshen.fiszki

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pl.revolshen.fiszki.data.model.Card
import pl.revolshen.fiszki.data.model.domain.GameEvent
import pl.revolshen.fiszki.data.model.domain.GameState
import pl.revolshen.fiszki.data.model.domain.MenuEvent
import pl.revolshen.fiszki.data.repositories.CardRepository
import pl.revolshen.fiszki.data.repositories.GameRepository
import pl.revolshen.fiszki.data.repositories.HistoryRepository

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val historyRepository = HistoryRepository(app)
    private val gameRepository = GameRepository(historyRepository)
    private val cardRepository = CardRepository(app)

    val gameState = gameRepository.getGameState()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(),
            initialValue = GameState.NotStarted
        )

    val historyState = historyRepository.getAllHistoryGames()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(),
            initialValue = emptyList()
        )

    fun handleMenuEvent(menuEvent: MenuEvent) = viewModelScope.launch {
        when (menuEvent) {
            MenuEvent.NewGame -> {
                val success = loadCards()
                if (success) {
                    gameRepository.startGame(getCards())
                }
            }

            MenuEvent.History -> {}
        }
    }

    fun handleGameEvent(gameEvent: GameEvent) = viewModelScope.launch {
        when (gameEvent) {
            is GameEvent.Check -> {
                gameRepository.checkUserAnswer(userAnswer = gameEvent.userAnswer)
            }

            is GameEvent.Next -> {
                gameRepository.nextQuestion(
                    correctAnswers = gameEvent.correctAnswers,
                    alreadyShownCards = gameEvent.alreadyShownCards
                )
            }
        }
    }

    private fun loadCards(): Boolean {
        return cardRepository.loadCards()
    }

    private fun getCards(): List<Card> {
        return cardRepository.getCards()
    }
}