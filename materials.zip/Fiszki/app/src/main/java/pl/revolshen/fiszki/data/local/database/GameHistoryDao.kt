package pl.revolshen.fiszki.data.local.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import pl.revolshen.fiszki.data.model.dto.GameHistoryDto

@Dao
interface GameHistoryDao {

    @Query("SELECT * FROM game_history")
    fun getAllHistoryGames(): Flow<List<GameHistoryDto>>

    @Insert
    fun insert(gameHistoryDto: GameHistoryDto)

    @Delete
    fun delete(gameHistoryDto: GameHistoryDto)
}